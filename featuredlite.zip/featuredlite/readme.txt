== Theme: Featured lite ==
* By ThemeHunk, http://themehunk.com/

Featured Lite
== Description ==
Featured Lite One Page Business theme comes with a unique and new design. It has background option and slider option, It offers live customizer to check changes instantly. It has Team section, Testimonial section, Woo-commerce section, Recent Post section, About Us section, Ribbon section, Service Section. Theme support Woocommerce, bbPress, Lead form builder, Contactform7 and many other famous WordPress plugin.

== Theme License & Copyright ==
Featured Lite WordPress theme, copyright (c) 2017 theme hunk.com
Featured Lite Theme is distributed under the terms of the GNU GPL3

License for images:
1. Image Name: bg.jpg
Resource link: https://pixabay.com/en/guitar-classical-guitar-756326/
Licensed under the CCO license.
License link : https://pixabay.com/en/service/terms/#usage

== Theme License & Copyright ==
Featured-lite is distributed under the terms of the GNU GPL
Featured-lite-Copyright 2014 Featured-lite, ThemeHunk.com
License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

== Open Sans Font ==
License URL: http://scripts.sil.org/OFL

== Font Awesome CSS license ==
License: MIT License
License URL for CSS : http://opensource.org/licenses/mit-license.html

== animate.css ==
animate.css, Copyright Daniel Eden License: MIT  Source : https://github.com/daneden/animate.css

== classie.js ==
Licensed under the MIT license
License URL for CSS : http://opensource.org/licenses/mit-license.html

== WOW.js ==
license : GNU GPL license v3
License URL : https://github.com/matthieua/WOW

==breadcrumb.php ==
breadcrumbs.php, Copyright Justin Tadlock License: GNU GPL License, version 0.2.1 
Source: https://github.com/justintadlock/breadcrumb-trail/

==Pro customizer section==
licensed : GNU GPL, version 2 or later
Source: https://github.com/justintadlock/trt-customizer-pro

==  Other Licenses ==
See headers of files for further details.
custom.js, jquery.flexslider.js, jssor.core.js, live-customizer.js, owl-carousel.js, widget.js is distributed under the terms of the MIT

Once again, thank you so much for trying the Featured-lite WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.


== Changelog ==

= 1.0 =
* Released: June 18, 2017

Initial release
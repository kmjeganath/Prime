<?php if( shortcode_exists( 'themehunk-customizer' ) ): ?>
<div class="container">	
<ul class="main-feature">
	<?php do_shortcode('[themehunk-customizer section="three-column"]'); ?>
</ul>
</div>
<?php endif; ?>
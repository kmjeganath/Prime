<!-- contact section start -->
<?php if(!th_checkbox_filter('contact','section_on_off')) : 
?>
<section id="contact" class="contact-section">
<div class="container">
  <?php do_shortcode('[themehunk-customizer section="contact_us"]'); 
        ?>
</div>
</section>
<?php endif; ?>
<!-- team section end -->